#' This function calculates population density in a scenario.
#' Population density is the amount of inhabitants per built-up area
#' in a scenario
#'
#' METHOD:
#' The population density (population density) is calculated by dividing the total number of inhabitants
#' (pop.tot) by the total built-up area (urban.fp).
#' The total population of the urban area (pop.tot) is calculated as the sum
#' of the population of each pixel, this calculation uses the total population function (tot.pop), while the
#' total build-up area is calculated as the sum of build-up area of each pixel, using the urban footprint function (urban.footprint)
#' The total population and urban footprint functions are included in this package.
#' NOTE: If user provide a stack in any of the parameters, the should must have the same number of layers for population
#' and footprint stack.
#'
#' @param pop a raster layer or raster stack that contains the population distribution in the base or horizon year
#' @param fp a raster layer or raster stack that contains the footprint in the base or horizon year
#' @return a data frame with information about the population density indicator calculated in inhabitants per square kilometer,
#' total population, and the total footprint calculated in square kilometers per each scenario.
#' @import raster
#' @import dplyr
#' @export
#' @examples
#' library(raster)
#' population.b <- system.file("extdata", "POP_2025.tif", package = "UPtooltest")
#' population.b <- raster::raster(population.b )
#' footprint.base <- system.file("extdata", "Build_up_2025.tif", package = "UPtooltest")
#' footprint.base <- raster::raster(footprint.base)
#'
#' pop.dens <- population.density(population.b, footprint.base)
population.density <- function(pop, fp){
  pop <- stack(pop)
  fp <- stack(fp)
  if(nlayers(pop) != nlayers(fp)){
    warning("Please provide the same number of population and urban footprint layers")
  }
  fp <- rasterchecker(fp, base = pop)
  nl <- as.numeric(max(nlayers(pop), nlayers(fp)))
  r <- lapply(1:nl, function(i){
    p <- pop[[i]]
    b <- fp[[i]]
    pop.tot <- as.numeric(tot.pop(p)$value)
    urban.fp <- as.numeric(urban.footprint(b)$value)
    pop.dens <- round(pop.tot/urban.fp, 2)
    density <- data.frame(
      indicator =  c("Total population", "Footprint area", "Population density"),
      fclass = c(names(p), names(b), "density"),
      value = c(pop.tot, urban.fp, pop.dens),
      units = c("inhabitants", "km2", "inh/km2")
    )
    return(density)
  })%>% bind_rows()
  return(r)
}
